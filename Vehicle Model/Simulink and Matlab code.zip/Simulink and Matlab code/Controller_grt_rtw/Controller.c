/*
 * Controller.c
 *
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * Code generation for model "Controller".
 *
 * Model version              : 1.55
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Thu Mar 30 18:01:58 2017
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Controller.h"
#include "Controller_private.h"

/* Block signals (auto storage) */
B_Controller_T Controller_B;

/* Continuous states */
X_Controller_T Controller_X;

/* Block states (auto storage) */
DW_Controller_T Controller_DW;

/* External inputs (root inport signals with auto storage) */
ExtU_Controller_T Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
ExtY_Controller_T Controller_Y;

/* Real-time model */
RT_MODEL_Controller_T Controller_M_;
RT_MODEL_Controller_T *const Controller_M = &Controller_M_;

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = (ODE3_IntgData *)rtsiGetSolverData(si);
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 4;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) memcpy(y, x,
                (uint_T)nXc*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Controller_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  Controller_step();
  Controller_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  Controller_step();
  Controller_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void Controller_step(void)
{
  real_T rtb_Plantcurrentslip;
  real_T rtb_Sum1;
  real_T rtb_Motorparameter;
  real_T rtb_Saturation_n;
  real_T rtb_Sum;
  if (rtmIsMajorTimeStep(Controller_M)) {
    /* set solver stop time */
    if (!(Controller_M->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&Controller_M->solverInfo,
                            ((Controller_M->Timing.clockTickH0 + 1) *
        Controller_M->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&Controller_M->solverInfo,
                            ((Controller_M->Timing.clockTick0 + 1) *
        Controller_M->Timing.stepSize0 + Controller_M->Timing.clockTickH0 *
        Controller_M->Timing.stepSize0 * 4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(Controller_M)) {
    Controller_M->Timing.t[0] = rtsiGetT(&Controller_M->solverInfo);
  }

  /* TransferFcn: '<S1>/Plant (current//slip)' */
  rtb_Plantcurrentslip = Controller_P.Plantcurrentslip_C *
    Controller_X.Plantcurrentslip_CSTATE;

  /* Sum: '<S1>/Sum1' incorporates:
   *  Inport: '<Root>/Drivering current'
   */
  rtb_Sum1 = Controller_U.Driveringcurrent - rtb_Plantcurrentslip;

  /* Saturate: '<S1>/Saturation' */
  if (rtb_Sum1 > Controller_P.Saturation_UpperSat) {
    rtb_Motorparameter = Controller_P.Saturation_UpperSat;
  } else if (rtb_Sum1 < Controller_P.Saturation_LowerSat) {
    rtb_Motorparameter = Controller_P.Saturation_LowerSat;
  } else {
    rtb_Motorparameter = rtb_Sum1;
  }

  /* End of Saturate: '<S1>/Saturation' */

  /* Gain: '<S3>/Motor parameter' */
  rtb_Motorparameter *= Controller_P.T;

  /* Gain: '<S3>/Drive train ratio' */
  Controller_B.Drivetrainratio = Controller_P.TR * rtb_Motorparameter;

  /* TransferFcn: '<S4>/Transfer Fcn' */
  rtb_Saturation_n = Controller_P.TransferFcn_C *
    Controller_X.TransferFcn_CSTATE + Controller_P.TransferFcn_D *
    Controller_B.Drivetrainratio;

  /* Saturate: '<S4>/Saturation' */
  if (rtb_Saturation_n > Controller_P.Saturation_UpperSat_k) {
    rtb_Saturation_n = Controller_P.Saturation_UpperSat_k;
  } else {
    if (rtb_Saturation_n < Controller_P.Saturation_LowerSat_k) {
      rtb_Saturation_n = Controller_P.Saturation_LowerSat_k;
    }
  }

  /* End of Saturate: '<S4>/Saturation' */

  /* Switch: '<S1>/Switch' incorporates:
   *  Constant: '<S1>/Constant1'
   *  Inport: '<Root>/Feedback status'
   */
  if (Controller_U.Feedbackstatus > Controller_P.Switch_Threshold) {
    rtb_Sum = rtb_Saturation_n;
  } else {
    rtb_Sum = Controller_P.Constant1_Value;
  }

  /* End of Switch: '<S1>/Switch' */

  /* Sum: '<S1>/Sum' incorporates:
   *  Constant: '<S1>/Ideal tire slip'
   */
  rtb_Sum = Controller_P.Idealtireslip_Value - rtb_Sum;

  /* Outport: '<Root>/Slip error' */
  Controller_Y.Sliperror = rtb_Sum;

  /* MATLAB Function: '<S1>/Bang Bang Controller' */
  /* MATLAB Function 'Controller/Bang Bang Controller': '<S2>:1' */
  /* Only active while slip signal is negtive  */
  if (!(rtb_Sum < 0.0)) {
    /* '<S2>:1:6' */
    rtb_Sum = 0.0;
  } else {
    /* '<S2>:1:3' */
    /* '<S2>:1:4' */
  }

  /* Outport: '<Root>/Slip error 2' incorporates:
   *  MATLAB Function: '<S1>/Bang Bang Controller'
   */
  /* '<S2>:1:9' */
  Controller_Y.Sliperror2 = rtb_Sum;

  /* Outport: '<Root>/Feedback current' */
  Controller_Y.Feedbackcurrent = rtb_Plantcurrentslip;

  /* Outport: '<Root>/Motor torque' */
  Controller_Y.Motortorque = rtb_Motorparameter;

  /* Outport: '<Root>/Drivetrain torque' */
  Controller_Y.Drivetraintorque = Controller_B.Drivetrainratio;

  /* Outport: '<Root>/Tire slip' */
  Controller_Y.Tireslip = rtb_Saturation_n;

  /* Outport: '<Root>/Current error' */
  Controller_Y.Currenterror = rtb_Sum1;

  /* Saturate: '<S5>/Saturation' incorporates:
   *  MATLAB Function: '<S1>/Bang Bang Controller'
   */
  if (rtb_Sum > Controller_P.Saturation_UpperSat_f) {
    Controller_B.Saturation = Controller_P.Saturation_UpperSat_f;
  } else if (rtb_Sum < Controller_P.Saturation_LowerSat_c) {
    Controller_B.Saturation = Controller_P.Saturation_LowerSat_c;
  } else {
    Controller_B.Saturation = rtb_Sum;
  }

  /* End of Saturate: '<S5>/Saturation' */
  if (rtmIsMajorTimeStep(Controller_M)) {
  }

  /* Gain: '<S5>/Gain' */
  Controller_B.Gain = Controller_P.wn * Controller_P.wn / Controller_P.A *
    Controller_B.Saturation;

  /* Gain: '<S5>/Gain1' incorporates:
   *  TransferFcn: '<S5>/Gc'
   */
  Controller_B.Gain1 = ((Controller_P.Gc_C[0] * Controller_X.Gc_CSTATE[0] +
    Controller_P.Gc_C[1] * Controller_X.Gc_CSTATE[1]) + Controller_P.Gc_D *
                        Controller_B.Gain) * Controller_P.Gain1_Gain;
  if (rtmIsMajorTimeStep(Controller_M)) {
  }

  if (rtmIsMajorTimeStep(Controller_M)) {
    /* Matfile logging */
    rt_UpdateTXYLogVars(Controller_M->rtwLogInfo, (Controller_M->Timing.t));
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep(Controller_M)) {
    /* signal main to stop simulation */
    {                                  /* Sample time: [0.0s, 0.0s] */
      if ((rtmGetTFinal(Controller_M)!=-1) &&
          !((rtmGetTFinal(Controller_M)-(((Controller_M->Timing.clockTick1+
               Controller_M->Timing.clockTickH1* 4294967296.0)) * 0.4)) >
            (((Controller_M->Timing.clockTick1+Controller_M->Timing.clockTickH1*
               4294967296.0)) * 0.4) * (DBL_EPSILON))) {
        rtmSetErrorStatus(Controller_M, "Simulation finished");
      }
    }

    rt_ertODEUpdateContinuousStates(&Controller_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++Controller_M->Timing.clockTick0)) {
      ++Controller_M->Timing.clockTickH0;
    }

    Controller_M->Timing.t[0] = rtsiGetSolverStopTime(&Controller_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.4s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.4, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      Controller_M->Timing.clockTick1++;
      if (!Controller_M->Timing.clockTick1) {
        Controller_M->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void Controller_derivatives(void)
{
  XDot_Controller_T *_rtXdot;
  _rtXdot = ((XDot_Controller_T *) Controller_M->derivs);

  /* Derivatives for TransferFcn: '<S1>/Plant (current//slip)' */
  _rtXdot->Plantcurrentslip_CSTATE = 0.0;
  _rtXdot->Plantcurrentslip_CSTATE += Controller_P.Plantcurrentslip_A *
    Controller_X.Plantcurrentslip_CSTATE;
  _rtXdot->Plantcurrentslip_CSTATE += Controller_B.Gain1;

  /* Derivatives for TransferFcn: '<S4>/Transfer Fcn' */
  _rtXdot->TransferFcn_CSTATE = 0.0;
  _rtXdot->TransferFcn_CSTATE += Controller_P.TransferFcn_A *
    Controller_X.TransferFcn_CSTATE;
  _rtXdot->TransferFcn_CSTATE += Controller_B.Drivetrainratio;

  /* Derivatives for TransferFcn: '<S5>/Gc' */
  _rtXdot->Gc_CSTATE[0] = 0.0;
  _rtXdot->Gc_CSTATE[0] += Controller_P.Gc_A[0] * Controller_X.Gc_CSTATE[0];
  _rtXdot->Gc_CSTATE[1] = 0.0;
  _rtXdot->Gc_CSTATE[0] += Controller_P.Gc_A[1] * Controller_X.Gc_CSTATE[1];
  _rtXdot->Gc_CSTATE[1] += Controller_X.Gc_CSTATE[0];
  _rtXdot->Gc_CSTATE[0] += Controller_B.Gain;
}

/* Model initialize function */
void Controller_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Controller_M, 0,
                sizeof(RT_MODEL_Controller_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&Controller_M->solverInfo,
                          &Controller_M->Timing.simTimeStep);
    rtsiSetTPtr(&Controller_M->solverInfo, &rtmGetTPtr(Controller_M));
    rtsiSetStepSizePtr(&Controller_M->solverInfo,
                       &Controller_M->Timing.stepSize0);
    rtsiSetdXPtr(&Controller_M->solverInfo, &Controller_M->derivs);
    rtsiSetContStatesPtr(&Controller_M->solverInfo, (real_T **)
                         &Controller_M->contStates);
    rtsiSetNumContStatesPtr(&Controller_M->solverInfo,
      &Controller_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&Controller_M->solverInfo,
      &Controller_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&Controller_M->solverInfo,
      &Controller_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&Controller_M->solverInfo,
      &Controller_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&Controller_M->solverInfo, (&rtmGetErrorStatus
      (Controller_M)));
    rtsiSetRTModelPtr(&Controller_M->solverInfo, Controller_M);
  }

  rtsiSetSimTimeStep(&Controller_M->solverInfo, MAJOR_TIME_STEP);
  Controller_M->intgData.y = Controller_M->odeY;
  Controller_M->intgData.f[0] = Controller_M->odeF[0];
  Controller_M->intgData.f[1] = Controller_M->odeF[1];
  Controller_M->intgData.f[2] = Controller_M->odeF[2];
  Controller_M->contStates = ((X_Controller_T *) &Controller_X);
  rtsiSetSolverData(&Controller_M->solverInfo, (void *)&Controller_M->intgData);
  rtsiSetSolverName(&Controller_M->solverInfo,"ode3");
  rtmSetTPtr(Controller_M, &Controller_M->Timing.tArray[0]);
  rtmSetTFinal(Controller_M, 20.0);
  Controller_M->Timing.stepSize0 = 0.4;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    Controller_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Controller_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Controller_M->rtwLogInfo, (NULL));
    rtliSetLogT(Controller_M->rtwLogInfo, "tout");
    rtliSetLogX(Controller_M->rtwLogInfo, "");
    rtliSetLogXFinal(Controller_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Controller_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Controller_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(Controller_M->rtwLogInfo, 0);
    rtliSetLogDecimation(Controller_M->rtwLogInfo, 1);
    rtliSetLogY(Controller_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Controller_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Controller_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &Controller_B), 0,
                sizeof(B_Controller_T));

  /* states (continuous) */
  {
    (void) memset((void *)&Controller_X, 0,
                  sizeof(X_Controller_T));
  }

  /* states (dwork) */
  (void) memset((void *)&Controller_DW, 0,
                sizeof(DW_Controller_T));

  /* external inputs */
  (void)memset((void *)&Controller_U, 0, sizeof(ExtU_Controller_T));

  /* external outputs */
  (void) memset((void *)&Controller_Y, 0,
                sizeof(ExtY_Controller_T));

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(Controller_M->rtwLogInfo, 0.0, rtmGetTFinal
    (Controller_M), Controller_M->Timing.stepSize0, (&rtmGetErrorStatus
    (Controller_M)));

  /* InitializeConditions for TransferFcn: '<S1>/Plant (current//slip)' */
  Controller_X.Plantcurrentslip_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<S4>/Transfer Fcn' */
  Controller_X.TransferFcn_CSTATE = 0.0;

  /* InitializeConditions for TransferFcn: '<S5>/Gc' */
  Controller_X.Gc_CSTATE[0] = 0.0;
  Controller_X.Gc_CSTATE[1] = 0.0;
}

/* Model terminate function */
void Controller_terminate(void)
{
  /* (no terminate code required) */
}
