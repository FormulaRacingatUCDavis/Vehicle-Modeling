/*
 * Controller_data.c
 *
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * Code generation for model "Controller".
 *
 * Model version              : 1.55
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Thu Mar 30 18:01:58 2017
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Controller.h"
#include "Controller_private.h"

/* Block parameters (auto storage) */
P_Controller_T Controller_P = {
  140.0,                               /* Variable: A
                                        * Referenced by: '<S5>/Gain'
                                        */
  0.21,                                /* Variable: T
                                        * Referenced by: '<S3>/Motor parameter'
                                        */
  4.6,                                 /* Variable: TR
                                        * Referenced by: '<S3>/Drive train ratio'
                                        */
  70.0,                                /* Variable: wn
                                        * Referenced by: '<S5>/Gain'
                                        */
  0.2,                                 /* Expression: 0.2
                                        * Referenced by: '<S1>/Ideal tire slip'
                                        */
  -47.519999999999996,                 /* Computed Parameter: Plantcurrentslip_A
                                        * Referenced by: '<S1>/Plant (current//slip)'
                                        */
  46044.223602484468,                  /* Computed Parameter: Plantcurrentslip_C
                                        * Referenced by: '<S1>/Plant (current//slip)'
                                        */
  600.0,                               /* Expression: 600
                                        * Referenced by: '<S1>/Saturation'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Saturation'
                                        */
  -9.9999999999999982,                 /* Computed Parameter: TransferFcn_A
                                        * Referenced by: '<S4>/Transfer Fcn'
                                        */
  0.0084354945466056565,               /* Computed Parameter: TransferFcn_C
                                        * Referenced by: '<S4>/Transfer Fcn'
                                        */
  0.00022482661371550259,              /* Computed Parameter: TransferFcn_D
                                        * Referenced by: '<S4>/Transfer Fcn'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<S4>/Saturation'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S4>/Saturation'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Constant1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S1>/Switch'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<S5>/Saturation'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S5>/Saturation'
                                        */

  /*  Computed Parameter: Gc_A
   * Referenced by: '<S5>/Gc'
   */
  { -105.0, -0.0 },

  /*  Computed Parameter: Gc_C
   * Referenced by: '<S5>/Gc'
   */
  { 4.5, 140.0 },
  0.1,                                 /* Computed Parameter: Gc_D
                                        * Referenced by: '<S5>/Gc'
                                        */
  -1.0                                 /* Expression: -1
                                        * Referenced by: '<S5>/Gain1'
                                        */
};
