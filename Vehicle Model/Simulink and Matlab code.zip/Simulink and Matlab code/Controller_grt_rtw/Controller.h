/*
 * Controller.h
 *
 * Student License - for use by students to meet course requirements and
 * perform academic research at degree granting institutions only.  Not
 * for government, commercial, or other organizational use.
 *
 * Code generation for model "Controller".
 *
 * Model version              : 1.55
 * Simulink Coder version : 8.12 (R2017a) 16-Feb-2017
 * C source code generated on : Thu Mar 30 18:01:58 2017
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Controller_h_
#define RTW_HEADER_Controller_h_
#include <string.h>
#include <float.h>
#include <stddef.h>
#ifndef Controller_COMMON_INCLUDES_
# define Controller_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* Controller_COMMON_INCLUDES_ */

#include "Controller_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlkStateChangeFlag
# define rtmGetBlkStateChangeFlag(rtm) ((rtm)->blkStateChange)
#endif

#ifndef rtmSetBlkStateChangeFlag
# define rtmSetBlkStateChangeFlag(rtm, val) ((rtm)->blkStateChange = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

/* Block signals (auto storage) */
typedef struct {
  real_T Drivetrainratio;              /* '<S3>/Drive train ratio' */
  real_T Saturation;                   /* '<S5>/Saturation' */
  real_T Gain;                         /* '<S5>/Gain' */
  real_T Gain1;                        /* '<S5>/Gain1' */
} B_Controller_T;

/* Block states (auto storage) for system '<Root>' */
typedef struct {
  struct {
    void *LoggedData;
  } Scope_PWORK;                       /* '<S5>/Scope' */

  struct {
    void *LoggedData;
  } Scope1_PWORK;                      /* '<S5>/Scope1' */

  struct {
    void *LoggedData;
  } Scope2_PWORK;                      /* '<S5>/Scope2' */
} DW_Controller_T;

/* Continuous states (auto storage) */
typedef struct {
  real_T Plantcurrentslip_CSTATE;      /* '<S1>/Plant (current//slip)' */
  real_T TransferFcn_CSTATE;           /* '<S4>/Transfer Fcn' */
  real_T Gc_CSTATE[2];                 /* '<S5>/Gc' */
} X_Controller_T;

/* State derivatives (auto storage) */
typedef struct {
  real_T Plantcurrentslip_CSTATE;      /* '<S1>/Plant (current//slip)' */
  real_T TransferFcn_CSTATE;           /* '<S4>/Transfer Fcn' */
  real_T Gc_CSTATE[2];                 /* '<S5>/Gc' */
} XDot_Controller_T;

/* State disabled  */
typedef struct {
  boolean_T Plantcurrentslip_CSTATE;   /* '<S1>/Plant (current//slip)' */
  boolean_T TransferFcn_CSTATE;        /* '<S4>/Transfer Fcn' */
  boolean_T Gc_CSTATE[2];              /* '<S5>/Gc' */
} XDis_Controller_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* External inputs (root inport signals with auto storage) */
typedef struct {
  real_T Driveringcurrent;             /* '<Root>/Drivering current' */
  real_T Feedbackstatus;               /* '<Root>/Feedback status' */
} ExtU_Controller_T;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct {
  real_T Sliperror;                    /* '<Root>/Slip error' */
  real_T Sliperror2;                   /* '<Root>/Slip error 2' */
  real_T Feedbackcurrent;              /* '<Root>/Feedback current' */
  real_T Motortorque;                  /* '<Root>/Motor torque' */
  real_T Drivetraintorque;             /* '<Root>/Drivetrain torque' */
  real_T Tireslip;                     /* '<Root>/Tire slip' */
  real_T Currenterror;                 /* '<Root>/Current error' */
} ExtY_Controller_T;

/* Parameters (auto storage) */
struct P_Controller_T_ {
  real_T A;                            /* Variable: A
                                        * Referenced by: '<S5>/Gain'
                                        */
  real_T T;                            /* Variable: T
                                        * Referenced by: '<S3>/Motor parameter'
                                        */
  real_T TR;                           /* Variable: TR
                                        * Referenced by: '<S3>/Drive train ratio'
                                        */
  real_T wn;                           /* Variable: wn
                                        * Referenced by: '<S5>/Gain'
                                        */
  real_T Idealtireslip_Value;          /* Expression: 0.2
                                        * Referenced by: '<S1>/Ideal tire slip'
                                        */
  real_T Plantcurrentslip_A;           /* Computed Parameter: Plantcurrentslip_A
                                        * Referenced by: '<S1>/Plant (current//slip)'
                                        */
  real_T Plantcurrentslip_C;           /* Computed Parameter: Plantcurrentslip_C
                                        * Referenced by: '<S1>/Plant (current//slip)'
                                        */
  real_T Saturation_UpperSat;          /* Expression: 600
                                        * Referenced by: '<S1>/Saturation'
                                        */
  real_T Saturation_LowerSat;          /* Expression: 0
                                        * Referenced by: '<S1>/Saturation'
                                        */
  real_T TransferFcn_A;                /* Computed Parameter: TransferFcn_A
                                        * Referenced by: '<S4>/Transfer Fcn'
                                        */
  real_T TransferFcn_C;                /* Computed Parameter: TransferFcn_C
                                        * Referenced by: '<S4>/Transfer Fcn'
                                        */
  real_T TransferFcn_D;                /* Computed Parameter: TransferFcn_D
                                        * Referenced by: '<S4>/Transfer Fcn'
                                        */
  real_T Saturation_UpperSat_k;        /* Expression: 1
                                        * Referenced by: '<S4>/Saturation'
                                        */
  real_T Saturation_LowerSat_k;        /* Expression: 0
                                        * Referenced by: '<S4>/Saturation'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S1>/Constant1'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S1>/Switch'
                                        */
  real_T Saturation_UpperSat_f;        /* Expression: 0
                                        * Referenced by: '<S5>/Saturation'
                                        */
  real_T Saturation_LowerSat_c;        /* Expression: -1
                                        * Referenced by: '<S5>/Saturation'
                                        */
  real_T Gc_A[2];                      /* Computed Parameter: Gc_A
                                        * Referenced by: '<S5>/Gc'
                                        */
  real_T Gc_C[2];                      /* Computed Parameter: Gc_C
                                        * Referenced by: '<S5>/Gc'
                                        */
  real_T Gc_D;                         /* Computed Parameter: Gc_D
                                        * Referenced by: '<S5>/Gc'
                                        */
  real_T Gain1_Gain;                   /* Expression: -1
                                        * Referenced by: '<S5>/Gain1'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_Controller_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;
  X_Controller_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T blkStateChange;
  real_T odeY[4];
  real_T odeF[3][4];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (auto storage) */
extern P_Controller_T Controller_P;

/* Block signals (auto storage) */
extern B_Controller_T Controller_B;

/* Continuous states (auto storage) */
extern X_Controller_T Controller_X;

/* Block states (auto storage) */
extern DW_Controller_T Controller_DW;

/* External inputs (root inport signals with auto storage) */
extern ExtU_Controller_T Controller_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExtY_Controller_T Controller_Y;

/* Model entry point functions */
extern void Controller_initialize(void);
extern void Controller_step(void);
extern void Controller_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Controller_T *const Controller_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('Traction_Control_main_code_Youla3/Controller')    - opens subsystem Traction_Control_main_code_Youla3/Controller
 * hilite_system('Traction_Control_main_code_Youla3/Controller/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Traction_Control_main_code_Youla3'
 * '<S1>'   : 'Traction_Control_main_code_Youla3/Controller'
 * '<S2>'   : 'Traction_Control_main_code_Youla3/Controller/Bang Bang Controller'
 * '<S3>'   : 'Traction_Control_main_code_Youla3/Controller/Power&Drivetrain (torque//current)'
 * '<S4>'   : 'Traction_Control_main_code_Youla3/Controller/Tire Slip Calculation'
 * '<S5>'   : 'Traction_Control_main_code_Youla3/Controller/Youla Controller'
 */
#endif                                 /* RTW_HEADER_Controller_h_ */
